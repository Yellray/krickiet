*PADS-LIBRARY-PART-TYPES-V9*

1070TR 1070TR I ANA 9 1 0 0 0
TIMESTAMP 2026.02.21.16.39.18
"Manufacturer_Name" Keystone Electronics
"Manufacturer_Part_Number" 1070TR
"Mouser Part Number" 534-1070TR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Keystone-Electronics/1070TR?qs=76dmnhCH%2FMN2NfD64M7eLg%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Battery Holder (Open) Coin, 20.0mm 1 Cell SMD (SMT) Tab -50C ~ 145C
"Datasheet Link" https://www.keyelco.com/product-pdf.cfm?p=14018
"Geometry.Height" 6.22mm
GATE 1 2 0
1070TR
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
996056/1585334/2.50/2/3/Hardware
